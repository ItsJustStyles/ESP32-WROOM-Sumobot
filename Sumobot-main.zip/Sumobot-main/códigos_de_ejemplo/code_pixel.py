# Tomás de Camino Beck
# Escuela de Sistemas Inteligentes
# Universidad Cenfotec

#Ejemplo de uso del Led RGB

import board
from ideaboard import IdeaBoard

ib = IdeaBoard()

## CODIGO PRINCIPAL ##

while True:
    ib.pixel = (150,0)
